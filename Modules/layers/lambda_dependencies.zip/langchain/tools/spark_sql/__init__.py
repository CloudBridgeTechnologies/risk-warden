"""Tools for interacting with Spark SQL."""
